stde <-
function(x) sd(x)/sqrt(length(x))
